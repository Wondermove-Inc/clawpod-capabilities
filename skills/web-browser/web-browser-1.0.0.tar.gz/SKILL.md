---
name: web-browser
description: "Human-like browser automation via Playwright accessibility tree and screenshots. Use when: web browsing, form filling, clicking buttons, navigating web apps, UI testing, taking web screenshots."
---

# Web Browser Skill — Human-like Browser Automation

에이전트가 사람처럼 웹 브라우저를 사용할 수 있게 하는 스킬.
접근성 트리 + 스크린샷 하이브리드 방식으로 높은 정밀도 제공.

## Description

웹 브라우저를 사람이 마우스와 키보드로 사용하는 것처럼 자동화합니다.
접근성 트리(Accessibility Tree)로 요소를 정확히 파악하고,
스크린샷으로 시각적 상태를 확인하여 정밀한 조작이 가능합니다.

## Usage

에이전트가 웹 브라우저 작업을 요청받았을 때 이 스킬을 사용합니다:
- 웹사이트 탐색, 정보 수집
- 웹 앱 조작 (로그인, 폼 작성, 버튼 클릭)
- 웹 기반 관리 도구 사용 (Huly, GitHub 등)
- 시각적 확인이 필요한 UI 테스트

## Architecture

Playwright MCP를 기반으로 접근성 트리 + 스크린샷 하이브리드 워크플로우를 제공합니다.
